A=[2 3 4;0 1 2;0 0 3];
b=[6;5;6]
n=max(size(A))
x=zeros(n,1)
x(n,:)=b(n,:)/A(n,n);
sum=0;
for i = n-1:-1:1
    sum=0;
    for j=i+1:n
        sum = sum+ x(j)*A(i,j)
    end
    sum;
    x(i,:)=2*(b(i,:)-sum)/A(i,i)
end
disp "hi"
disp(x(2))