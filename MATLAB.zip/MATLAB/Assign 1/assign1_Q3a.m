% Lab Assign 1 Ques 3(i)

clear all
clc

syms x
 f=@(x) x^2-29


tol = 0.001; %tolerance
h=1;
n1 = -10; %-N
n2 = 10;  %N

for i = n1:h:n2   %IVT
    if(f(i)*f(i+h)<0)
        a=i;
        b=i+h;
        break;  %required for smallest possible root; remove it for a positive root
    end
end

disp("The interval is ");
disp(a);
disp(b);

count = 0;  % number of iterations
while(abs(a-b)>tol)
    c=(a+b)/2;
    if(f(a)*f(c)<0)
        b=c;
    else
        a=c;
    end
    count = count + 1;
end


disp("The answer is ");
disp(c)

 