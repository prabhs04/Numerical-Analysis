% Lab Assign 1 Ques 3(ii)

clear all
clc

syms x
 f=@(x) x^3+4*x^2-10


tol = 0.001; %tolerance
a=1;
b=2;

count = 0;  % number of iterations
while(abs(a-b)>tol)
    c=(a+b)/2;
    if(f(a)*f(c)<0)
        b=c;
    else
        a=c;
    end
    count = count + 1;
end

disp("The number if iterations is ");
disp(count)
disp("The answer is ");
disp(c)

 