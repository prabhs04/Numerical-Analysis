% Lab Assign 2 : Secant

clear all
clc

syms x
% f=@(x) x^2-17;
% f=@(x) x-2*sin(x)
f=@(x) x^3-x^2-6*x



tol = 0.00001;
i=1;
N=20;
flag=-1
h=1;
n1 = -10; %-N
n2 = 10;  %N

for i = n1:h:n2   %IVT
    if(f(i)*f(i+h)<0)
        x0=i;
        x1=i+h;
        break;  %required for smallest possible root; remove it for a positive root
    end
end
%x1,x0
i=1
while(i<=N)
    x2 = x1 - (( x1 - x0 )*f(x1)/(f(x1)-f(x0)));
    
    if(abs(x2-x1)<tol)
        disp("Root is :");
        disp(x2);
        flag = 1;
        break;
    
    else
        i=i+1;
        x0=x1;
        x1=x2;
    end
end

if(flag==-1)
    disp("Root not found!");
end