% A = [10,8,-3,1,16;2,10,1,-4,9;3,-4,10,1,10;2,2,-3,10,11]
clear all
clc
A=[5,5,0,0,0, 5.5;0,0,1,-1,-1, 0;0,0,0,2,-3, 0;1,-1,-1,0,0, 0;0,5,-7,-2,0,0];
B=[5.5;0;0;0;0];
n=5 %col %row
m=zeros(n,n);

for i=1:n-1
    for j=i+1:n
        if(A(i,i)<=A(i,j))
            temp=A(i,:);
            A(i,:)=A(j,:);
            A(j,:)=temp;
        end
    end
end

for i=1:n-1
    for j=i+1:n
        m(j,i)=A(j,i)/A(i,i)  %multiplier can also be named as m(j,i)
        A(j,:)=A(j,:)-m(j,i)*A(i,:)  %operation
    end
end

if(A(n,n)==0)
    display("No unique solution")
end
display(A)

% Gauss elimination
x(n)=A(n,n+1)/A(n,n)
for i=n-1:-1:1
    sum=0
    for j=i+1:n
        sum=sum+(A(i,j)*x(j))
    end
        
    x(i)=(A(i,n+1)-sum)/A(i,i);
end

display("The solution is :");
for i=1:n
    display(x(i))
end
% display(x)

% %LU decomp
% U=A;
% L=zeros(n,n);
% for i=1:n
%      L(i,i)=1;
%     for j=i+1:n
%        L(j,i)=m(j,i);
%     end
% end
% %Ax=B => (LU)x=B => Ly=B and Ux=y
% 
% Y=inv(L)*B;
% o=inv(U)*Y;
% 
% display(o)


