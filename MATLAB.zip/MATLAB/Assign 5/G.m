n=3;
A=[4.63,-1.21,3.22;-3.07,5.48,2.11;1.26,3.11,4.57]
B=[2.22;-3.17;5.11]
x0=[0;0;0]
x=[0;0;0]
tol=0.001
N=100
k=1;

while k<=N
    for i=1:n
        
        sum1=0;
        for j=1:i-1
            sum1=sum1+A(i,j)*x(j);
        end
        
        sum2=0;
        for j=i+1:n
            sum2=sum2+A(i,j)*x0(j);
        end
        
        x(i)=(-sum1-sum2+B(i))/A(i,i);
    end
    
    if max((abs(x-x0))<tol)
        break;
    end
    
    x0=x;
    k=k+1;
end
x  %answer
A*x  %--> to check

