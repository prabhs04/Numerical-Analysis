%Gauss Seidel

n=4;
A=[10,8,-3,1;2,10,1,-4;3,-4,10,1;2,2,-3,10]
B=[16;9;10;11]
x0=[0;0;0;0]
x=[0;0;0;0]
tol=0.001
N=10
k=1;
while k<=N
    for i=1:n
        
        sum1=0;
        for j=1:i-1
            sum1=sum1+a(i,j)*x(j);
        end
        
        sum2=0;
        for j=i+1:n
            sum2=sum2+a(i,j)*x0(j);
        end
        
        x(i)=(1-w)*x0(i)+w*(-sum1-sum2+b(i))/a(i,i);
    end
    
    if max((abs(x-x0))<tol)
        break;
    end
    
    x0=x;
    k=k+1;
end
x
k
