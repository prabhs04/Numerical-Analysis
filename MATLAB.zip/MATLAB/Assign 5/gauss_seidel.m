%Gauss Seidel


% A=[10,8,-3,1;2,10,1,-4;3,-4,10,1;2,2,-3,10]
% B=[16;9;10;11]
A=[4,1,-1,1;1,4,-1,-1;-1,-1,5,1;1,-1,1,3]
B=[-2;-1;0;1]
x0=[0;0;0;0]
x=[0;0;0;0]
n=4;
w=1.2  %given in question, usually 0 < w < 1 
% n=3;
% A=[4.63,-1.21,3.22;-3.07,5.48,2.11;1.26,3.11,4.57]
% B=[2.22;-3.17;5.11]
% x0=[0;0;0]
% x=[0;0;0]
tol=0.001
N=20
k=1;
while k<=N
    for i=1:n
        
        sum1=0;
        for j=1:i-1
            sum1=sum1+A(i,j)*x(j);
        end
        
        sum2=0;
        for j=i+1:n
            sum2=sum2+A(i,j)*x0(j);
        end
        
      %  x(i)=(-sum1-sum2+B(i))/A(i,i);
        x(i)=(1-w)*x0(i)+w*(-sum1-sum2+B(i))/A(i,i);
    end
    
    for j=1:n
        temp(j)=abs(x(j)-x0(j))
    end
    if max((abs(temp))<=tol)
        x
        break;
    end
    
    x0=x;
    k=k+1;
end
x
A*x

