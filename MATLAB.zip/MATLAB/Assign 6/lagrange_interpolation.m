%Lagrange

clc;
% input the data pts
% for i=1:n
%     X(i)=input("data pt")
%     Y(i)=input("data pt")
% end

n=6;
X=[0;8;16;24;32;40];
Y=[14.621;11.843;9.870;8.418;7.305;6.413];
% X=linspace(0,2*pi,8)
% Y=(sin(X)).^2
% n=8
%  X=[0 (2*pi)/7 (4*pi)/7 (6*pi)/7 (8*pi)/7 (10*pi)/7 (12*pi)/7 2*pi];
%  Y=[0 (sin(2*pi/7))^2 (sin(4*pi/7))^2 (sin(6*pi/7))^2 (sin(8*pi/7))^2 (sin(10*pi/7))^2 (sin(12*pi/7))^2 0];

x=27;
sum=0;
for i=1:n
    l(i)=1;
    for j=1:n
    if i~=j
        l(i)= ((x-X(j))/(X(i)-X(j)))*l(i);
    end
    end
    sum=sum+l(i)*Y(i);
end

display(sum);

% Answers:-
% Ques 4a) O(15)=10.0834
%      4b) O(27)=7.9682
% Ques 5) f(0.5)=0.0293
%          f(3.5)=0.1317
%          f(5.5)=0.4477
%          f(6)  =-0.1810

             
