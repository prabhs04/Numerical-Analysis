clc;
n=20;
X=linspace(0,2*pi,n)
Y=(sin(X)).^2
%  X=[0 (2*pi)/7 (4*pi)/7 (6*pi)/7 (8*pi)/7 (10*pi)/7 (12*pi)/7 2*pi];
%  Y=[0 (sin(2*pi/7))^2 (sin(4*pi/7))^2 (sin(6*pi/7))^2 (sin(8*pi/7))^2 (sin(10*pi/7))^2 (sin(12*pi/7))^2 0];
x=0.5;
sum=0;
for i=1:n
    l(i)=1;
    for j=1:n
    if i~=j
        l(i)= ((x-X(j))/(X(i)-X(j)))*l(i);
    end
    end
    sum=sum+l(i)*Y(i);
end

sum



% Answers:-
% Ques 5) f(0.5)=0.0293
%          f(3.5)=0.1317
%          f(5.5)=0.4477
%          f(6)  =-0.1810
             
