%Power Method
clc;

A=[3 0 0;0 -1 0;0 0 -5];
x0=[1;1;1];

% A=[1,1,0,0;1,2,0,1;0,0,3,3;0,1,2,3];
% x0=[1;1;0;1];
tol=0.001;
e=1;
k0=10;
i=0
while e>tol
    y=A*x0;
    k=max(abs(y));
%     display(k)
    e=abs(k-k0);
    k0=k;
    x0=(1/k)*y
    i=i+1
end
   display(i)
   display(k)
   display(x0)
   
   
%    Answers:-
%    Ques 2a) 20.1241
%    Ques 2b) 5.6022
  

   
   
    