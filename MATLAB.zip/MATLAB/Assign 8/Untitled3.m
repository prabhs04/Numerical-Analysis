% Least Sq. 

clc;
x=[-2, -1, 0, 1, 2];
y=[15, 1, 1, 3, 19];
n=4;
plot(x,y,'*')
hold on

A=[n sum(x) sum(x.*x); sum(x) sum(x.*x) sum(x.^3); sum(x.^2) sum(x.^3) sum(x.^4)];
B=[sum(y); sum(x.*y); sum(x.*x.*y)];
X=inv(A)*B;
a=X(1);
b=X(2);
c=X(3);
disp(a)
disp(b)
disp(c)
syms z;
f=@(z) a+b*z +c*(z.^2)
fplot(f)