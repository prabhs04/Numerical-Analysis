% Simpson

clc;
syms x
f=@(x) (cos(x)).^2;
a=-0.25;
b=0.25;
n=4;
h=(b-a)/n;

sum1=0;
for i=1:n-1
    x=a+i*h;
    if(rem(i,2)==0)
        sum1=sum1+2*f(x);
    else
        sum1=sum1+4*f(x);
    end
end

ans=(h/3)*(f(a)+f(b)+sum1);
disp(ans)


% x=a+h*[1:4];
% ans1=(h/2)*(f(a)+f(b)+2.*sum(f(x)));
% disp(ans1);