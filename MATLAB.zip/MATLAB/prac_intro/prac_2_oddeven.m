c = input('Enter a string : ') 
a = (-1)^c;

if a == -1
    disp('input is odd')
else
    disp('input is even')
end

% if(rem(c,2)==0)
%     disp('even')
% else
%     disp('odd')
% end
 