x = -10:0.2:10;
y = -20:0.4:20; % y=2*x

plot(x,y);

% plot(x,y,':k') dotted line
% plot(x,y,'*k') star line
% plot(x,y,'+k') plus line

hold on %after this, every curve will be plotted on this graph

x=-5:0.1:5;
y=3*x.^2

plot(x,y,':r')

hold off 
   %counterpart of hold on (hold on can be used in cmd 
   %window for immediate effect)
   
  