c = input('Enter a number : ') 
sum = 0;

i=0;

while c>0
    i = rem(c,10);
    sum = sum + i;
    disp(sum);
    c = (c-i)/10;
end

disp('Sum is ');
disp(sum);


% n = 19
% d = 3
% r = rem(n,d)
% q = (n-r)/d
% disp(q,r)

