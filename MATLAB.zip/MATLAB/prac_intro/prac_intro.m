% c = input('Enter a string')
    %lets us take any input
%     
% a=10;
% b=10;
% 
% if(a==b)
%     disp('a is equal to b')
% end
%% 
% sum = 0;
% a=zeros(1,5);
% for i=1:5
%     sum = sum + i;
%  a(i)=a(i)-57;
% end
% 
% disp(sum);

% 
% b=100;
% 
% while(b>=0)
%     disp( b);
%     b=b-15;
% end
%% 
% 
% syms x 
%      %give x the value of a symbol
% 
% f=@(x) x^2+1
% 
% f(2);

%% 

syms x y z

    